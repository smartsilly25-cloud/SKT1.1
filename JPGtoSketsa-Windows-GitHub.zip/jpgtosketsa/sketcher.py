"""Mesin sketsa (port dari Sketcher.kt): arsir pensil searah bentuk (LIC), garis detail, kertas."""
from __future__ import annotations

from dataclasses import dataclass

import cv2
import numpy as np

from .common import box_blur, hash_rnd, logistic, rint, smoothstep as sm, to_rgba, zscore

INK_MAX = 0.90
LINE_W = 0.45
FLAT_WIDE = 1.6
FLAT_TOOTH = 0.7
FLAT_DIR = 0.85
TONE_SOFT = 1.25
FLAT_SOFT = 0.85
FLAT_SOFT_R = 1.5
POST_BLUR = 1


@dataclass
class SketchParams:
    mode: int = 3     # 0 pensil, 1 pensil berwarna, 2 garis tegas, 3 arsir, 4 arsir + AI, 5 arsir berwarna + AI
    blur: int = 40    # 0..100 ketebalan/kehalusan garis
    dark: int = 70    # 0..100 kegelapan
    color: int = 75   # 0..100 kekuatan warna
    grain: int = 55   # 0..100 tekstur kertas
    paper: int = 0    # 0 putih, 1 krem, 2 papan tulis, 3 transparan (PNG, hanya garis)


def render_hd(src: np.ndarray, p: SketchParams, ai_lines=None, upscaler=None) -> np.ndarray:
    """Seperti render(), tapi foto kecil diperbesar dulu (mode arsir) supaya goresan tetap halus."""
    h, w = src.shape[:2]
    big = max(w, h)
    if p.mode < 3 or big >= 1400:
        return render(src, p, ai_lines)
    work = src
    ai = False
    if big <= 650 and upscaler is not None:
        sr = upscaler(src)
        if sr is not None:
            work, ai = sr, True
    b2 = max(work.shape[:2])
    target = int(np.clip(b2, 1400, 1800)) if ai else 1400
    if b2 != target:
        f = target / b2
        work = cv2.resize(work, (rint(work.shape[1] * f), rint(work.shape[0] * f)), interpolation=cv2.INTER_AREA if f < 1 else cv2.INTER_CUBIC)
    return render(work, p, ai_lines)


def render(src: np.ndarray, p: SketchParams, ai_lines=None) -> np.ndarray:
    """src: RGBA/RGB uint8. ai_lines: fungsi(src_rgb)->float 0..255 (HxW) atau None. Hasil RGBA uint8."""
    src = to_rgba(src)
    h, w = src.shape[:2]
    rgb = src[..., :3].astype(np.float32)
    scale = max(w, h) / 900.0
    gray = np.floor((rgb[..., 0] * 299 + rgb[..., 1] * 587 + rgb[..., 2] * 114) / 1000.0)

    ln = None
    if p.mode >= 3:
        if p.mode == 5 and p.paper in (0, 1):
            v, ln = _hatch(gray, p, scale, True)
        else:
            v = _hatch(gray, p, scale)
        if p.mode >= 4 and ai_lines is not None:
            ai = ai_lines(src)
            if ai is not None:
                v = np.floor(v * (1.0 - 0.20 * (1.0 - ai / 255.0)))
    elif p.mode == 2:
        g = box_blur(gray, max(1, rint((1 + p.blur * 0.12) * scale)))
        gain = 1.5 + p.dark * 0.06
        gx = cv2.Sobel(g, cv2.CV_32F, 1, 0, ksize=3, borderType=cv2.BORDER_REPLICATE)
        gy = cv2.Sobel(g, cv2.CV_32F, 0, 1, ksize=3, borderType=cv2.BORDER_REPLICATE)
        v = 255 - np.minimum(255, (np.abs(gx) + np.abs(gy)) * gain / 2.0)
        v[0, :] = v[-1, :] = 255
        v[:, 0] = v[:, -1] = 255
    else:
        inv = box_blur(255 - gray, max(1, rint((2 + p.blur * 0.38) * scale)))
        gamma = 0.6 + p.dark / 100.0 * 1.4
        d = np.maximum(1.0, 256 - inv)
        t = np.minimum(255, gray * 256 / d) / 255.0
        v = np.clip(255.0 * t ** gamma, 0, 255)

    if p.mode == 5 and p.paper in (0, 1) and ln is not None:
        return _comic_look(src, gray, v, ln, scale, p)

    colored = p.mode in (1, 5)
    kc = p.color / 100.0
    gr = p.grain / 100.0 * (0.5 if p.mode >= 3 else 1.0)
    idx = np.arange(h * w, dtype=np.int64).reshape(h, w)
    noise = ((idx.astype(np.uint32) * np.uint32(0x9E3779B1)) >> np.uint32(24)).astype(np.float32) / 255.0
    vv = v * (1.0 - gr * 0.25 * noise)

    if colored:
        lc = 255.0 * (1 - kc) + rgb * kc            # HxWx3
    else:
        lc = np.full((h, w, 3), 255.0, np.float32)

    out = np.empty((h, w, 4), np.uint8)
    if p.paper == 3:
        al = np.clip(np.floor(255.0 - vv), 0, 255)
        if colored:
            col = np.clip(np.floor(lc * 0.5), 0, 255)
        else:
            col = np.empty((h, w, 3), np.float32)
            col[...] = (20, 20, 24)
        out[..., :3] = col.astype(np.uint8)
        out[..., 3] = al.astype(np.uint8)
        return out

    if p.paper == 2:
        t = ((255.0 - vv) / 255.0)[..., None]
        base = np.array([43.0, 58.0, 51.0], np.float32)
        c = base + (lc - base) * t
    else:
        pc = np.array([245.0, 236.0, 215.0], np.float32) if p.paper == 1 else np.array([255.0] * 3, np.float32)
        c = vv[..., None] * lc / 255.0 * pc / 255.0
    out[..., :3] = np.clip(np.floor(c), 0, 255).astype(np.uint8)
    out[..., 3] = 255
    return out


# ------------------------------------------------------------------ arsir
def _flow_field(t: np.ndarray, scale: float):
    gx = np.zeros_like(t)
    gy = np.zeros_like(t)
    gx[1:-1, 1:-1] = t[1:-1, 2:] - t[1:-1, :-2]
    gy[1:-1, 1:-1] = t[2:, 1:-1] - t[:-2, 1:-1]
    r = max(2, rint(7 * scale))
    jxx = box_blur(gx * gx, r)
    jyy = box_blur(gy * gy, r)
    jxy = box_blur(gx * gy, r)
    ax = jxx - jyy
    ay = 2 * jxy
    tr = jxx + jyy + 150.0
    ang = 0.5 * np.arctan2(-ay / tr - 0.25, -ax / tr)
    return np.cos(ang).astype(np.float32), np.sin(ang).astype(np.float32)


def _flatness(tone: np.ndarray, scale: float) -> np.ndarray:
    gx = np.zeros_like(tone)
    gy = np.zeros_like(tone)
    gx[1:-1, 1:-1] = tone[1:-1, 2:] - tone[1:-1, :-2]
    gy[1:-1, 1:-1] = tone[2:, 1:-1] - tone[:-2, 1:-1]
    gm = np.floor(np.sqrt(gx * gx + gy * gy) * 4.0)
    gm = box_blur(gm, max(2, rint(3 * scale)))
    return 1.0 - sm(3.0, 12.0, gm / 4.0 * scale)


def _lic(noise: np.ndarray, fx: np.ndarray, fy: np.ndarray, steps: int, stp: float) -> np.ndarray:
    h, w = noise.shape
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    s = noise.copy()
    dx = fx * stp
    dy = fy * stp
    for k in range(1, steps + 1):
        ox = dx * k
        oy = dy * k
        ya = np.clip(yy + oy + 0.5, 0, h - 1).astype(np.int32)
        xa = np.clip(xx + ox + 0.5, 0, w - 1).astype(np.int32)
        s += noise[ya, xa]
        yb = np.clip(yy - oy + 0.5, 0, h - 1).astype(np.int32)
        xb = np.clip(xx - ox + 0.5, 0, w - 1).astype(np.int32)
        s += noise[yb, xb]
    return s / (2 * steps + 1)


def _detail_lines(gray: np.ndarray, scale: float) -> np.ndarray:
    def rr(sig):
        return max(1, rint(sig - 0.5))

    gd = box_blur(gray * 4.0, rr(0.9 * scale))
    dog1 = box_blur(gd, rr(0.9 * scale)) - box_blur(gd, rr(1.8 * scale))
    dog2 = box_blur(gd, rr(1.7 * scale)) - box_blur(gd, rr(3.4 * scale))
    gx = np.zeros_like(gd)
    gy = np.zeros_like(gd)
    gx[1:-1, 1:-1] = gd[1:-1, 2:] - gd[1:-1, :-2]
    gy[1:-1, 1:-1] = gd[2:, 1:-1] - gd[:-2, 1:-1]
    gm = box_blur(np.floor(np.sqrt(gx * gx + gy * gy)), rr(1.5 * scale))
    es = gm / 4.0 * scale
    gate = sm(5.0, 16.0, es)
    l1 = np.clip(-dog1 / 120.0, 0, 1) * 0.8
    l2 = np.clip(-dog2 / 150.0, 0, 1) * 0.5
    return np.clip(l1 + l2, 0, 1) * gate


def _hatch(gray: np.ndarray, p: SketchParams, scale: float, want_lines: bool = False):
    h, w = gray.shape
    n = h * w
    bl = box_blur(gray, max(1, rint(1.4 * scale - 0.5)))
    tone = np.clip(np.floor(gray + 0.3 * (gray - bl)), 0, 255)
    tone = np.floor(box_blur(tone, max(1, rint(0.6 * scale))))
    bl = box_blur(tone, max(2, rint(9 * scale - 0.5)))
    tone = np.clip(np.floor(tone + 0.3 * (tone - bl)), 0, 255)
    ti = tone.astype(np.int32)

    hist = np.bincount(ti.ravel(), minlength=256)
    cs = np.cumsum(hist)
    lo = min(255, int(np.searchsorted(cs, n * 0.01, side="left")))
    rcs = np.cumsum(hist[::-1])
    hi = 255 - min(255, int(np.searchsorted(rcs, n * 0.01, side="left")))
    if hi - lo < 32:
        lo, hi = 0, 255
    inv = 1.0 / (hi - lo)
    gamma = 1.0 / (0.55 + p.dark / 100.0 * 1.1)

    mt = float(np.clip(np.clip((tone - lo) * inv, 0, 1).mean(), 0.05, 0.95))
    ex = float(np.clip(np.log(0.58) / np.log(mt), 0.45, 1.0))
    tv = np.arange(256, dtype=np.float32)
    dlut = ((1.0 - np.clip((tv - lo) * inv, 0, 1) ** ex) ** gamma).astype(np.float32)

    fx, fy = _flow_field(tone, scale)
    flat = _flatness(tone, scale)

    yy, xx = np.mgrid[0:h, 0:w]
    cw = max(1, rint(FLAT_WIDE * scale))
    srcn = hash_rnd((yy // cw) * 100003 + (xx // cw) + 7)
    press = zscore(_lic(srcn, fx, fy, 12, max(1.0, scale)))
    srcn = hash_rnd(np.arange(n, dtype=np.int64).reshape(h, w) * 31 + 12345)
    fine = zscore(_lic(srcn, fx, fy, 9, max(1.0, scale * 0.8)))
    iso = np.floor(hash_rnd(np.arange(n, dtype=np.int64).reshape(h, w) * 17 + 99991) * 1023.0)
    iso = box_blur(iso, max(1, rint(FLAT_TOOTH * scale - 0.5)))
    mI = float(iso.mean())
    sdI = max(float(iso.std()), 1e-6)

    d = dlut[ti]
    pr = 0.5 + 0.22 * press
    dd = np.clip(d * (0.65 + 0.7 * pr), 0, 1)
    tooth = (1 - FLAT_DIR) * logistic((iso - mI) / sdI) + FLAT_DIR * logistic(fine)
    cov = np.clip((dd - 0.02 - tooth * 0.95) / 0.55 + 0.5, 0, 1) * sm(0.05, 0.35, d)
    sw = flat * (1.0 - sm(0.45, 0.80, d))
    dark = 0.55 * d ** 1.2 + 0.36 * cov * (1 - 0.30 * sw)
    dark = np.clip(dark, 0, 1) ** TONE_SOFT
    fxx = (xx - w * 0.5) / (w * 0.62)
    fyy = (yy - h * 0.45) / (h * 0.62)
    fade = 1.0 - 0.4 * sm(0.7, 1.5, fxx * fxx + fyy * fyy)
    dark = dark * fade
    v = np.clip(np.floor(255.0 * (1.0 - np.clip(dark, 0, 1) * INK_MAX)), 0, 255).astype(np.float32)

    vb = box_blur(v, max(1, rint(FLAT_SOFT_R * scale)))
    f = sw * FLAT_SOFT
    v = np.clip(np.floor(v + (vb - v) * f), 0, 255)
    if scale >= 1.0:
        k = np.array([1, 6, 1], np.float32) / 8.0
        for _ in range(POST_BLUR):
            v = cv2.sepFilter2D(v, -1, k, k, borderType=cv2.BORDER_REPLICATE)
            v = np.floor(v)

    ln = _detail_lines(gray, scale)
    m = ln > 0
    if m.any():
        fac = 1.0 - LINE_W * ln * (0.35 + 0.65 * (1.0 - d)) * fade
        v = np.where(m, np.clip(np.floor(v * fac), 0, 255), v)
    if want_lines:
        return v.astype(np.float32), ln
    return v.astype(np.float32)


# ------------------------------------------------------------------ gaya ilustrasi komik (Arsir Berwarna + AI)
# Peta kecerahan -> warna, diambil dari gambar referensi: bayangan hijau-hitam, tengah hijau zaitun redup, sorotan ocher krem.
_PALETTE_L = np.array([0, 9, 25, 45, 59, 71, 84, 102, 122, 143, 176, 216, 255], np.float32)
_PALETTE_RGB = np.array([[6, 7, 6], [10, 11, 8], [24, 27, 22], [42, 48, 43], [54, 62, 59], [65, 73, 69], [80, 88, 79],
                         [101, 106, 93], [123, 125, 107], [150, 145, 121], [188, 180, 152], [232, 215, 169],
                         [244, 234, 205]], np.float32)
_INK_RGB = np.array([20, 24, 20], np.float32)
_PAPER_RGB = {0: np.array([242, 236, 220], np.float32), 1: np.array([240, 228, 200], np.float32)}


def _comic_look(src: np.ndarray, gray: np.ndarray, v: np.ndarray, ln: np.ndarray, scale: float, p: SketchParams) -> np.ndarray:
    """Warna ala ilustrasi graphic novel: nada warna TETAP (tidak mengikuti warna asli foto), kontur tinta tebal,
    arsiran, tekstur kertas. Kekuatan warna = seberapa banyak warna asli ikut (0 = palet murni)."""
    h, w = gray.shape
    rgb = src[..., :3].astype(np.float32)
    kc = p.color / 100.0 * 0.6
    # 1) Nada: haluskan seperti sapuan cat, regangkan kontras, angkat tengah sedikit
    g8 = np.clip(gray, 0, 255).astype(np.uint8)
    sig_s = max(3.0, 5.0 * scale)
    sm_ = g8
    for _ in range(2):
        sm_ = cv2.bilateralFilter(sm_, 0, 28, sig_s)
    t = sm_.astype(np.float32)
    lo, hi = np.percentile(t, 1.5), np.percentile(t, 98.5)
    t = np.clip((t - lo) / max(hi - lo, 1.0), 0, 1)
    t = t ** (0.85 + 0.5 * (1 - p.dark / 100.0))
    t = 0.80 * t + 0.20 * np.floor(t * 6.0 + 0.5) / 6.0           # sedikit pengelompokan nada (kesan cat datar)
    t = cv2.GaussianBlur(t, (0, 0), max(0.8, 0.7 * scale))
    lut = np.stack([np.interp(np.arange(256), _PALETTE_L, _PALETTE_RGB[:, c]) for c in range(3)], 1).astype(np.float32)
    lum_l = (0.299 * lut[:, 0] + 0.587 * lut[:, 1] + 0.114 * lut[:, 2])[:, None]
    lut = np.clip(lum_l + (lut - lum_l) * 1.45, 0, 255)               # kejenuhan palet seperti referensi (zaitun-ocher)
    col = lut[np.clip((t * 255).astype(np.int32), 0, 255)]
    # sedikit warna asli (diredam ke palet) bila diminta
    if kc > 0:
        lum = (0.299 * rgb[..., 0] + 0.587 * rgb[..., 1] + 0.114 * rgb[..., 2])[..., None]
        tint = col * (1 + (rgb - lum) / 255.0 * 1.2)
        col = col * (1 - kc) + np.clip(tint, 0, 255) * kc
    # 2) Tinta: arsiran (dari v) + kontur tebal (garis detail dan garis AI yang sudah masuk ke v)
    hatch_t = np.clip((255.0 - v) / (255.0 * INK_MAX), 0, 1)
    ink_a = np.clip(hatch_t ** 1.15 * (0.30 + 0.55 * (p.dark / 100.0)), 0, 0.85)
    out = col * (1 - ink_a[..., None]) + _INK_RGB * ink_a[..., None]
    cw_ = max(1, rint(0.6 * scale))
    cont = ln if cw_ <= 1 else cv2.dilate(ln.astype(np.float32), np.ones((2, 2), np.uint8))
    cont = np.clip(cont * 1.7, 0, 1) * 0.90
    out = out * (1 - cont[..., None]) + _INK_RGB * cont[..., None]
    # 3) Kertas: butiran, serat, tepi memudar ke kertas
    idx = np.arange(h * w, dtype=np.int64).reshape(h, w)
    noise = hash_rnd(idx * 7 + 31)
    fib = cv2.GaussianBlur(noise, (0, 0), max(1.0, 1.4 * scale))
    fib = (fib - fib.mean()) / max(float(fib.std()), 1e-6)
    gr = p.grain / 100.0
    out = out * (1 + gr * (0.07 * (noise - 0.5) + 0.05 * fib)[..., None])
    yy, xx = np.mgrid[0:h, 0:w]
    fx = (xx - w * 0.5) / (w * 0.62)
    fy = (yy - h * 0.45) / (h * 0.62)
    e = sm(0.9, 1.7, fx * fx + fy * fy)[..., None] * 0.55
    paper = _PAPER_RGB[p.paper]
    out = out * (1 - e) + paper * e
    # tekanan kertas: sedikit bernoda di area terang supaya tidak datar
    res = np.empty((h, w, 4), np.uint8)
    res[..., :3] = np.clip(np.floor(out + 0.5), 0, 255).astype(np.uint8)
    res[..., 3] = 255
    return res
